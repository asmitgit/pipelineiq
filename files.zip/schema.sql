-- ═══════════════════════════════════════════════════════════════════
-- PIPELINEIQ DATABASE SCHEMA
-- Designed for all 3 IP layers from day one
-- Run this in your Supabase SQL editor
-- ═══════════════════════════════════════════════════════════════════

-- Enable UUID generation
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm"; -- for text similarity (Layer 3)

-- ─── LAYER 1: Core platform tables ────────────────────────────────

-- Organisations (maps to Clerk orgs)
CREATE TABLE organisations (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  clerk_org_id      TEXT UNIQUE NOT NULL,
  name              TEXT NOT NULL,
  vertical          TEXT CHECK (vertical IN ('bfsi','healthcare','bpo','telecom','technology','other')),
  company_size      TEXT CHECK (company_size IN ('1-50','51-200','201-1000','1000+')),
  pilot_status      TEXT DEFAULT 'active' CHECK (pilot_status IN ('active','completed','loi_sent','converted','churned')),
  audits_used       INTEGER DEFAULT 0,
  audits_limit      INTEGER DEFAULT 10, -- pilot limit
  contact_email     TEXT,
  notes             TEXT,               -- your internal notes on this customer
  created_at        TIMESTAMPTZ DEFAULT NOW(),
  updated_at        TIMESTAMPTZ DEFAULT NOW()
);

-- Users (maps to Clerk users)
CREATE TABLE users (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  clerk_user_id     TEXT UNIQUE NOT NULL,
  organisation_id   UUID REFERENCES organisations(id) ON DELETE CASCADE,
  email             TEXT NOT NULL,
  full_name         TEXT,
  role              TEXT DEFAULT 'member' CHECK (role IN ('admin','member','viewer')),
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- ─── LAYER 1 + 2: Audits table (every audit ever run) ─────────────
-- This is the most important table. Never delete rows. This IS your benchmark.

CREATE TABLE audits (
  id                    UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organisation_id       UUID REFERENCES organisations(id) ON DELETE CASCADE,
  user_id               UUID REFERENCES users(id),

  -- Audit classification
  audit_type            TEXT NOT NULL CHECK (audit_type IN ('readiness','cost')),
  use_case              TEXT NOT NULL CHECK (use_case IN ('voice','chat','copilot','rag','agentic','data')),
  source                TEXT NOT NULL CHECK (source IN ('live','engine')), -- live=Claude API, engine=built-in

  -- API fingerprint (used for Layer 3 graph)
  api_name              TEXT NOT NULL,
  api_url               TEXT,
  api_url_normalised    TEXT,            -- cleaned URL for deduplication
  auth_type             TEXT,
  platform              TEXT,            -- AI platform (Cognigy, NICE, etc.)
  vertical              TEXT,            -- copied from org for quick querying

  -- Readiness audit results
  overall_score         INTEGER CHECK (overall_score BETWEEN 0 AND 100),
  estimated_fix_weeks   INTEGER,

  -- Cost audit results
  savings_percent       INTEGER,
  current_monthly_cost  TEXT,
  optimized_monthly_cost TEXT,
  total_monthly_savings TEXT,

  -- Full report (JSONB so we can query inside it)
  report_data           JSONB NOT NULL,

  -- Dimension scores (extracted for fast benchmark queries)
  score_connectivity    INTEGER,
  score_auth            INTEGER,
  score_schema          INTEGER,
  score_latency         INTEGER,
  score_compliance      INTEGER,
  score_change_mgmt     INTEGER,

  -- Metadata
  pdf_url               TEXT,           -- Supabase storage URL for PDF
  created_at            TIMESTAMPTZ DEFAULT NOW()
);

-- Audit findings (extracted for pattern analysis — Layer 2 and 3)
CREATE TABLE audit_findings (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  audit_id        UUID REFERENCES audits(id) ON DELETE CASCADE,
  organisation_id UUID REFERENCES organisations(id) ON DELETE CASCADE,
  severity        TEXT CHECK (severity IN ('critical','high','medium','low')),
  title           TEXT NOT NULL,
  description     TEXT,
  fix             TEXT,
  dimension       TEXT,
  use_case        TEXT,
  api_name        TEXT,
  vertical        TEXT,
  confirmed       BOOLEAN,             -- did the customer confirm this was real?
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─── LAYER 2: Benchmark tables ────────────────────────────────────

-- Anonymised API signatures (no org/customer data — just API characteristics)
CREATE TABLE api_signatures (
  id                UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  api_name_hash     TEXT NOT NULL,      -- SHA256 of normalised API name
  api_url_pattern   TEXT,              -- e.g. "*.salesforce.com/services/data/v*"
  known_api_key     TEXT,              -- 'salesforce', 'sap', null if unknown
  auth_type         TEXT,
  vertical          TEXT,
  use_case          TEXT,
  avg_score         NUMERIC(4,1),
  avg_latency_score INTEGER,
  avg_auth_score    INTEGER,
  sample_count      INTEGER DEFAULT 1,
  last_seen         TIMESTAMPTZ DEFAULT NOW(),
  created_at        TIMESTAMPTZ DEFAULT NOW()
);

-- Benchmark snapshots (published quarterly)
-- Aggregated, anonymised. This is what you publish as "State of Enterprise AI Integration"
CREATE TABLE benchmark_snapshots (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  snapshot_date   DATE NOT NULL,
  period          TEXT NOT NULL,       -- 'Q1 2025', 'Q2 2025', etc.
  vertical        TEXT,               -- null = all verticals
  use_case        TEXT,               -- null = all use cases
  audit_type      TEXT,

  -- Readiness benchmarks
  median_score    NUMERIC(4,1),
  p25_score       NUMERIC(4,1),
  p75_score       NUMERIC(4,1),
  pct_pass        NUMERIC(5,2),       -- % scoring >= 75
  pct_fail        NUMERIC(5,2),       -- % scoring < 50

  -- Most common issues
  top_finding_1   TEXT,
  top_finding_2   TEXT,
  top_finding_3   TEXT,

  -- Cost benchmarks (for cost audits)
  median_savings_pct  NUMERIC(5,2),
  median_current_cost TEXT,

  -- Sample size (for credibility)
  sample_count    INTEGER,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ─── LAYER 3: Integration Intelligence Graph ──────────────────────
-- Populated as you accumulate data. Start collecting now, use later.

-- API nodes in the graph
CREATE TABLE graph_api_nodes (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  api_signature_id UUID REFERENCES api_signatures(id),
  known_api_key   TEXT,               -- 'salesforce', 'twilio', etc.
  canonical_name  TEXT NOT NULL,      -- clean display name
  category        TEXT,               -- 'crm', 'telephony', 'ehr', 'banking', etc.
  avg_score       NUMERIC(4,1),
  failure_rate    NUMERIC(5,2),       -- % of audits that scored < 50
  sample_count    INTEGER DEFAULT 0,
  created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- Edges: API combinations observed in the same deployment
CREATE TABLE graph_api_edges (
  id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  api_node_1      UUID REFERENCES graph_api_nodes(id),
  api_node_2      UUID REFERENCES graph_api_nodes(id),
  use_case        TEXT,
  co_occurrence   INTEGER DEFAULT 1, -- how often seen together
  avg_combined_score NUMERIC(4,1),
  common_failures JSONB,             -- top 3 failures for this combination
  created_at      TIMESTAMPTZ DEFAULT NOW(),
  updated_at      TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(api_node_1, api_node_2, use_case)
);

-- ─── LOI tracking (business layer) ────────────────────────────────
CREATE TABLE loi_tracking (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organisation_id     UUID REFERENCES organisations(id),
  status              TEXT DEFAULT 'pilot' CHECK (status IN ('pilot','verbal','loi_sent','loi_signed','converted','lost')),
  pilot_session_date  DATE,
  loi_sent_date       DATE,
  loi_signed_date     DATE,
  contract_value_usd  INTEGER,        -- annual contract value
  deployment_use_case TEXT,
  notes               TEXT,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Pilot sessions (structured record for investor reporting)
CREATE TABLE pilot_sessions (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  organisation_id     UUID REFERENCES organisations(id),
  session_date        DATE NOT NULL,
  attendees           JSONB,          -- [{name, title}]
  apis_audited        INTEGER,
  findings_confirmed  INTEGER,        -- customer confirmed as real
  findings_disputed   INTEGER,        -- customer said not relevant
  nps_score           INTEGER CHECK (nps_score BETWEEN 0 AND 10),
  key_reactions       TEXT,           -- your notes from the session
  follow_up_agreed    TEXT,
  loi_discussed       BOOLEAN DEFAULT FALSE,
  created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- ─── Row Level Security ────────────────────────────────────────────
-- Database-level multi-tenancy: each org ONLY sees their own data

ALTER TABLE organisations     ENABLE ROW LEVEL SECURITY;
ALTER TABLE users             ENABLE ROW LEVEL SECURITY;
ALTER TABLE audits            ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_findings    ENABLE ROW LEVEL SECURITY;
ALTER TABLE loi_tracking      ENABLE ROW LEVEL SECURITY;
ALTER TABLE pilot_sessions    ENABLE ROW LEVEL SECURITY;

-- benchmark and graph tables are aggregated/anonymised — no RLS needed
-- but they are read-only for non-service-role clients

-- RLS Policies: users see their org's data only
-- Note: We use service role key in API routes (bypasses RLS)
-- and anon key on client (respects RLS)

CREATE POLICY "Users see own org audits"
  ON audits FOR ALL
  USING (organisation_id IN (
    SELECT id FROM organisations WHERE clerk_org_id = (
      SELECT current_setting('app.clerk_org_id', TRUE)
    )
  ));

CREATE POLICY "Users see own org users"
  ON users FOR ALL
  USING (organisation_id IN (
    SELECT id FROM organisations WHERE clerk_org_id = (
      SELECT current_setting('app.clerk_org_id', TRUE)
    )
  ));

-- ─── Indexes for query performance ────────────────────────────────

-- Core queries
CREATE INDEX idx_audits_org         ON audits(organisation_id);
CREATE INDEX idx_audits_type        ON audits(audit_type);
CREATE INDEX idx_audits_use_case    ON audits(use_case);
CREATE INDEX idx_audits_created     ON audits(created_at DESC);
CREATE INDEX idx_audits_score       ON audits(overall_score);
CREATE INDEX idx_audits_vertical    ON audits(vertical);
CREATE INDEX idx_audits_api_name    ON audits USING gin(to_tsvector('english', api_name));

-- Benchmark queries (Layer 2)
CREATE INDEX idx_findings_severity  ON audit_findings(severity);
CREATE INDEX idx_findings_use_case  ON audit_findings(use_case);
CREATE INDEX idx_findings_vertical  ON audit_findings(vertical);

-- Graph queries (Layer 3)
CREATE INDEX idx_edges_node1        ON graph_api_edges(api_node_1);
CREATE INDEX idx_edges_node2        ON graph_api_edges(api_node_2);
CREATE INDEX idx_edges_use_case     ON graph_api_edges(use_case);

-- ─── Functions ────────────────────────────────────────────────────

-- Auto-update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_organisations_updated_at
  BEFORE UPDATE ON organisations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER update_loi_updated_at
  BEFORE UPDATE ON loi_tracking
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Function: get benchmark data for a use case + vertical
CREATE OR REPLACE FUNCTION get_benchmark(
  p_use_case TEXT,
  p_vertical TEXT DEFAULT NULL,
  p_audit_type TEXT DEFAULT 'readiness'
)
RETURNS TABLE (
  median_score    NUMERIC,
  p25_score       NUMERIC,
  p75_score       NUMERIC,
  sample_count    BIGINT,
  pct_scoring_75  NUMERIC
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY overall_score) AS median_score,
    PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY overall_score) AS p25_score,
    PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY overall_score) AS p75_score,
    COUNT(*) AS sample_count,
    ROUND(100.0 * COUNT(*) FILTER (WHERE overall_score >= 75) / COUNT(*), 1) AS pct_scoring_75
  FROM audits
  WHERE audit_type = p_audit_type
    AND use_case = p_use_case
    AND (p_vertical IS NULL OR vertical = p_vertical)
    AND overall_score IS NOT NULL;
END;
$$ LANGUAGE plpgsql;

-- ─── Views for dashboard ───────────────────────────────────────────

-- Admin view: audit statistics per organisation (you use this)
CREATE VIEW org_audit_stats AS
SELECT
  o.id,
  o.name,
  o.vertical,
  o.pilot_status,
  COUNT(a.id) AS total_audits,
  COUNT(a.id) FILTER (WHERE a.audit_type = 'readiness') AS readiness_audits,
  COUNT(a.id) FILTER (WHERE a.audit_type = 'cost') AS cost_audits,
  ROUND(AVG(a.overall_score) FILTER (WHERE a.audit_type = 'readiness'), 1) AS avg_readiness_score,
  MAX(a.created_at) AS last_audit_at
FROM organisations o
LEFT JOIN audits a ON a.organisation_id = o.id
GROUP BY o.id, o.name, o.vertical, o.pilot_status;
