# PipelineIQ — Enterprise Test Bed Setup Guide
## From zero to live URL in one day

---

## Prerequisites
- Node.js 18+ installed
- A GitHub account (free)
- A Vercel account (free) — vercel.com
- Credit card for domain registration (~$12)

---

## Step 1 — Accounts to create (30 minutes)

Create accounts at each service. All are free tier.

| Service | URL | What you need |
|---|---|---|
| Vercel | vercel.com | Connect GitHub repo |
| Clerk | clerk.com | Auth dashboard |
| Supabase | supabase.com | New project |
| Upstash | upstash.com | Redis database |
| Resend | resend.com | Email API |
| PDFShift | pdfshift.io | PDF generation ($9/month) |
| PostHog | posthog.com | Analytics |
| Namecheap | namecheap.com | Domain — pipelineiq.io (~$12) |
| Cloudflare | cloudflare.com | DNS + security (free) |

---

## Step 2 — Clerk configuration (20 minutes)

1. Create a new Clerk application
2. Under **Restrictions**, add blocked email domains:
   ```
   gmail.com, yahoo.com, hotmail.com, outlook.com, icloud.com, 
   protonmail.com, aol.com, ymail.com, rediffmail.com, live.com, msn.com
   ```
3. Enable **Organizations** in the Clerk dashboard
4. Under **Webhooks**, add endpoint: `https://pipelineiq.io/api/webhooks/clerk`
   - Subscribe to: `organization.created`, `user.created`, `organizationMembership.created`
5. Copy your **Publishable Key** and **Secret Key**

---

## Step 3 — Supabase setup (20 minutes)

1. Create a new Supabase project (choose Singapore region for India/APAC customers)
2. Go to **SQL Editor** and paste the entire contents of `supabase/schema.sql`
3. Run the SQL — this creates all tables, indexes, RLS policies, and functions
4. Go to **Storage**, create a public bucket called `reports`
5. Copy your **Project URL**, **anon key**, and **service_role key**

---

## Step 4 — Upstash Redis (5 minutes)

1. Create a new Redis database in Upstash
2. Select **Global** replication
3. Copy the **REST URL** and **REST Token**

---

## Step 5 — Resend (10 minutes)

1. Add your domain `pipelineiq.io` in Resend
2. Add the DNS records they provide to Cloudflare (SPF, DKIM, DMARC)
3. Copy your **API key**

---

## Step 6 — Deploy to Vercel (15 minutes)

```bash
# Clone and install
git clone https://github.com/YOUR_USERNAME/pipelineiq
cd pipelineiq
npm install

# Push to GitHub first, then connect in Vercel dashboard
git add .
git commit -m "Initial PipelineIQ platform"
git push origin main
```

In Vercel dashboard:
1. Import your GitHub repository
2. Add all environment variables from `.env.example`
3. Deploy

Your app is now live at `xxx.vercel.app`

---

## Step 7 — Custom domain (10 minutes)

1. In Vercel → Project → Domains → Add `pipelineiq.io`
2. In Namecheap → Change nameservers to Cloudflare
3. In Cloudflare → Add the A record Vercel provides
4. SSL auto-configures within 5 minutes

---

## Step 8 — Create first pilot customer (5 minutes)

1. Go to `pipelineiq.io/sign-up` 
2. Sign up with YOUR work email to create the first account
3. In Supabase SQL editor, update the pilot limit for your org:
   ```sql
   UPDATE organisations SET audits_limit = 50 WHERE clerk_org_id = 'YOUR_CLERK_ORG_ID';
   ```
4. Share `pipelineiq.io/sign-up` with your first pilot customer
5. In Clerk dashboard → Organizations → manually adjust their audit limit if needed

---

## Step 9 — Monitor your pilots

**Clerk dashboard** — see who is signed up, which companies
**Supabase** — query audit data:
```sql
-- See all audits with scores
SELECT api_name, use_case, overall_score, source, created_at 
FROM audits ORDER BY created_at DESC;

-- See benchmark data building up
SELECT * FROM org_audit_stats;
```
**PostHog** — see which features customers use most
**Resend** — see email delivery rates

---

## Giving a pilot customer access

When a pilot customer signs up:
1. They create a Clerk organization with their company name
2. Clerk webhook fires → Supabase creates their org with 10 audit limit
3. They can invite team members from the Clerk org dashboard
4. You can increase their limit in Supabase any time:
   ```sql
   UPDATE organisations 
   SET audits_limit = 25 
   WHERE name = 'Customer Company Name';
   ```

---

## What to tell enterprise customers about security

> "During your pilot, you describe API characteristics to PipelineIQ — 
> no live API calls are made to your systems, no credentials are 
> transmitted, and no production data is processed. Analysis runs 
> against what you describe. Your data is stored on Supabase (AWS 
> Singapore region), protected by row-level security so only your 
> organisation can access your audit results. We are happy to sign 
> an NDA before your pilot begins."

---

## Monthly costs at pilot stage

| Service | Cost |
|---|---|
| Vercel | $0 (free tier) |
| Clerk | $0 (free tier) |
| Supabase | $0 (free tier) |
| Upstash | $0 (free tier) |
| Resend | $0 (free tier) |
| PDFShift | $9/month |
| Anthropic API | ~$5-20/month (pay per use) |
| Domain | $1/month (paid annually) |
| **Total** | **~$15-30/month** |

---

## Troubleshooting

**Auth not working** — Check Clerk environment variables match exactly
**Database errors** — Verify Supabase service role key is set in Vercel
**PDF not generating** — Check PDFShift API key and billing status
**Rate limits** — Check Upstash dashboard for quota usage
**Emails not sending** — Verify Resend DNS records in Cloudflare

---

## Support
team@pipelineiq.io
