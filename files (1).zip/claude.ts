import Anthropic from '@anthropic-ai/sdk'
import type { ReadinessInput, CostInput, ReadinessReport, CostReport } from '@/types'

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY!,
})

const UC_NAMES: Record<string, string> = {
  voice: 'Voice bot', chat: 'Chat bot', copilot: 'AI co-pilot',
  rag: 'RAG pipeline', agentic: 'Agentic AI', data: 'Data AI',
}

function extractJSON(raw: string): string | null {
  try { JSON.parse(raw.trim()); return raw.trim() } catch (_) {}
  const fenced = raw.replace(/```(?:json)?\n?/gi, '').replace(/```/g, '').trim()
  try { JSON.parse(fenced); return fenced } catch (_) {}
  const start = raw.indexOf('{'), end = raw.lastIndexOf('}')
  if (start === -1 || end === -1) return null
  const candidate = raw.slice(start, end + 1)
  try { JSON.parse(candidate); return candidate } catch (_) {}
  return null
}

// ─── Readiness audit via Claude API ───────────────────────────────
export async function runReadinessWithClaude(input: ReadinessInput): Promise<ReadinessReport | null> {
  const ucName = UC_NAMES[input.uc] || input.uc
  const UC_H: Record<string, string> = {
    voice: 'p99 latency MUST be <200ms; concurrent sessions; graceful timeout; no blocking ops',
    chat: 'session state across turns; webhook reliability; rate limits under burst',
    copilot: 'sub-second responses; RBAC for sensitive data; audit logging',
    rag: 'rich filtering; cursor pagination; field completeness for embedding; data freshness',
    agentic: 'idempotency CRITICAL; long-running transactions; webhook events; rollback patterns',
    data: 'bulk/batch endpoints; high throughput; cursor pagination; strong consistency',
  }

  try {
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 4000,
      messages: [{
        role: 'user',
        content: `You are a senior API integration architect with 15 years enterprise experience in BFSI, healthcare, and telecom. Analyse this API for AI deployment readiness. Return ONLY valid JSON — no markdown, no text outside the JSON.

API: ${input.apiName}
URL: ${input.apiUrl || 'not provided'}
Auth: ${input.authType}
Spec/Description: ${input.spec || input.ctx || 'not provided — infer from API name and auth type'}
AI Use Case: ${ucName}
Platform: ${input.platform || 'not specified'}
Context: ${input.ctx || 'none'}
Use-case priorities: ${UC_H[input.uc] || 'general enterprise AI readiness'}

Return exactly this JSON (all string values max 60 words each):
{"overall_score":<0-100>,"verdict":"<2-3 sentences: verdict, biggest risk, top action>","estimated_fix_weeks":<int>,"dimensions":[{"name":"Connectivity & Discoverability","score":<0-100>,"status":"<pass|warn|fail>","summary":"<max 40 words>"},{"name":"Authentication & Authorization","score":<0-100>,"status":"<pass|warn|fail>","summary":"<max 40 words>"},{"name":"Schema & Data Contract","score":<0-100>,"status":"<pass|warn|fail>","summary":"<max 40 words>"},{"name":"Reliability & Latency","score":<0-100>,"status":"<pass|warn|fail>","summary":"<max 40 words>"},{"name":"Compliance & Data Governance","score":<0-100>,"status":"<pass|warn|fail>","summary":"<max 40 words>"},{"name":"Change Management","score":<0-100>,"status":"<pass|warn|fail>","summary":"<max 40 words>"}],"findings":[{"severity":"<critical|high|medium>","title":"<max 12 words>","description":"<max 50 words specific to this API and ${ucName}>","fix":"<max 50 words prescriptive action>"}],"use_case_risks":[{"risk":"<max 20 words>","impact":"<max 30 words>"}]}

Rules: 3-5 findings. Use real knowledge of well-known APIs. Scores 45-82 typical. Be specific and opinionated. IMPORTANT: Complete the full JSON — do not truncate.`
      }]
    })

    if (message.stop_reason === 'max_tokens') return null
    const raw = message.content.find(c => c.type === 'text')?.text || ''
    const js = extractJSON(raw)
    if (!js) return null
    return JSON.parse(js) as ReadinessReport
  } catch (err) {
    console.error('Claude readiness error:', err)
    return null
  }
}

// ─── Cost audit via Claude API ────────────────────────────────────
export async function runCostWithClaude(input: CostInput): Promise<CostReport | null> {
  const ucName = UC_NAMES[input.uc] || input.uc
  const extraParams = Object.entries(input)
    .filter(([k]) => !['apiName','apiDesc','payload','model','uc','customRate'].includes(k))
    .map(([k, v]) => `${k}: ${v}`)
    .join('\n')

  const MCOSTS: Record<string, number> = {
    claude: 3, claude3: 15, gpt4: 5, gpt35: 0.5,
    gemini: 3.5, llama: 0.5, mistral: 4, custom: parseFloat(input.customRate || '3')
  }
  const MODEL_NAMES: Record<string, string> = {
    claude: 'Claude Sonnet', claude3: 'Claude Opus', gpt4: 'GPT-4o',
    gpt35: 'GPT-3.5 Turbo', gemini: 'Gemini 1.5 Pro', llama: 'Llama 3',
    mistral: 'Mistral Large', custom: 'Custom model'
  }
  const mCost = MCOSTS[input.model] || 3
  const mName = MODEL_NAMES[input.model] || input.model

  try {
    const message = await anthropic.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 4000,
      messages: [{
        role: 'user',
        content: `You are a principal AI cost engineer specialising in LLM token optimisation for enterprise deployments. Analyse this API for token cost efficiency. Return ONLY valid JSON — no markdown.

API: ${input.apiName}
Use case: ${ucName}
Payload description: ${input.apiDesc || 'not described — infer from API name'}
Sample payload: ${input.payload || 'not provided'}
AI Model: ${mName} ($${mCost}/million input tokens)
Usage parameters:
${extraParams}
Context: ${input.ctx || 'enterprise AI deployment'}

Return exactly this JSON (all strings max 60 words):
{"current_monthly_cost":"<$X,XXX>","optimized_monthly_cost":"<$XXX>","total_monthly_savings":"<$X,XXX>","savings_percent":<int>,"verdict":"<3 sentences: cost situation, primary waste driver, total savings opportunity>","headline_metrics":[{"label":"<label>","val":"<value>","col":"<hex color>"}],"token_breakdown":{"current_in":<int>,"opt_in":<int>,"reduction":<int>},"optimizations":[{"type":"<payload_bloat|caching|response_flattening|field_pruning|context_stuffing|context_accumulation|retry_reduction|tool_result_summarisation|checkpointing|incremental_processing|model_tiering|chunk_size_reduction|topk_reduction|metadata_filtering|shared_agent_cache>","title":"<max 12 words>","description":"<max 50 words specific to this use case>","implementation":"<max 50 words prescriptive>","savings_per_month":"<$XXX/mo>","effort":"<low|medium|high>","effort_hours":<int>}],"caching_strategy":{"hit_rate":"<XX-XX%>","savings":"<$XXX>","fields":[{"field":"<path>","ttl":<seconds>,"freq":"<rare|moderate|frequent>"}]},"roadmap":[{"step":<int>,"action":"<max 10 words>","savings":"<$XXX/mo>","hours":<int>}]}

Generate 3-5 optimisations. Concrete $ estimates based on $${mCost}/M tokens and the usage parameters above. Sort optimisations by savings_per_month descending. IMPORTANT: Complete full JSON — do not truncate.`
      }]
    })

    if (message.stop_reason === 'max_tokens') return null
    const raw = message.content.find(c => c.type === 'text')?.text || ''
    const js = extractJSON(raw)
    if (!js) return null
    return JSON.parse(js) as CostReport
  } catch (err) {
    console.error('Claude cost error:', err)
    return null
  }
}
