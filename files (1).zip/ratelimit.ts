import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";
const redis = new Redis({ url: process.env.UPSTASH_REDIS_REST_URL!, token: process.env.UPSTASH_REDIS_REST_TOKEN! });
export const auditRatelimit = new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(10, "1 h"), prefix: "piq:audit:user" });
export const orgRatelimit = new Ratelimit({ redis, limiter: Ratelimit.slidingWindow(50, "1 h"), prefix: "piq:audit:org" });
export async function checkRateLimits(userId: string, orgId: string) {
  const [u, o] = await Promise.all([auditRatelimit.limit(userId), orgRatelimit.limit(orgId)]);
  if (!u.success) return { allowed: false, message: `User rate limit: ${u.limit}/hr. Resets in ${Math.round((u.reset - Date.now()) / 60000)} min.`, remaining: 0 };
  if (!o.success) return { allowed: false, message: `Org rate limit exceeded.`, remaining: 0 };
  return { allowed: true, remaining: u.remaining };
}