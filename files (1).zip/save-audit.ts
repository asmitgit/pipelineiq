import { createServerClient } from "./supabase";

function parseDollar(v: any): number | null {
  if (!v) return null;
  if (typeof v === "number") return v;
  const n = parseFloat(String(v).replace(/[^0-9.]/g, ""));
  return isNaN(n) ? null : n;
}

export async function saveAudit(params: {
  orgId: string; userId: string; auditType: string; useCase: string;
  inputs: Record<string, any>; result: Record<string, any>; source: string;
}) {
  const db = createServerClient(params.orgId);
  const { inputs: i, result: r } = params;

  const apiNameClean = (i.apiName || "").toLowerCase().replace(/[^a-z0-9]/g, "_").replace(/_+/g, "_").replace(/^_|_$/, "");
  let domain: string | null = null;
  try { if (i.apiUrl) domain = new URL(i.apiUrl).hostname; } catch (_) {}

  const row: Record<string, any> = {
    org_id: params.orgId, user_id: params.userId,
    audit_type: params.auditType, use_case: params.useCase,
    api_name: i.apiName, api_name_clean: apiNameClean,
    api_url: i.apiUrl || null, api_url_domain: domain,
    auth_type: i.authType || null, ai_platform: i.platform || null,
    spec_provided: !!(i.spec?.trim()), spec_length: i.spec?.length || 0,
    analysis_source: params.source, overall_score: r.overall_score || r.savings_percent,
    verdict: r.verdict, fix_weeks: r.estimated_fix_weeks || r.fix_weeks || null,
    include_in_benchmark: true,
  };

  if (params.auditType === "cost") {
    row.cost_model = i.model;
    row.current_monthly_cost_usd = parseDollar(r.current_monthly_cost);
    row.optimised_monthly_cost_usd = parseDollar(r.optimized_monthly_cost);
    row.total_savings_usd = parseDollar(r.total_monthly_savings);
    row.savings_percent = r.savings_percent;
    row.tokens_current_per_call = r.token_breakdown?.current_in;
    row.tokens_optimised_per_call = r.token_breakdown?.opt_in;
  }

  const { data: audit, error } = await db.from("audits").insert(row).select("id").single();
  if (error || !audit) { console.error("Save audit error:", error); return null; }
  const auditId = audit.id;

  if (r.dimensions?.length) {
    await db.from("audit_dimensions").insert(r.dimensions.map((d: any) => ({ audit_id: auditId, ...d })));
  }
  if (r.findings?.length) {
    await db.from("audit_findings").insert(r.findings.map((f: any) => ({ audit_id: auditId, severity: f.severity, title: f.title, description: f.description, fix: f.fix, type: f.type || null })));
  }
  if (r.optimizations?.length) {
    await db.from("audit_optimisations").insert(r.optimizations.map((o: any) => ({ audit_id: auditId, type: o.type, title: o.title, description: o.description, implementation: o.implementation, savings_usd: parseDollar(o.savings_per_month), effort: o.effort, effort_hours: o.effort_hours })));
  }

  await db.from("api_signatures").upsert({ name_clean: apiNameClean, display_name: i.apiName, domain, last_audited_at: new Date().toISOString() }, { onConflict: "name_clean" });

  return auditId;
}