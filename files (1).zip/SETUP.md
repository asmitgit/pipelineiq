# PipelineIQ — Complete Setup Guide
## From JSX prototype to Enterprise SaaS test bed

Time: 12-14 focused hours. Cost: ~$25/month. Result: A live platform you can share with enterprise pilot customers.

---

## BEFORE YOU START — Register accounts (30 mins, all free)

1. vercel.com — sign up with GitHub
2. clerk.com — create app "PipelineIQ"  
3. supabase.com — create project (pick region near your customers)
4. upstash.com — create Redis database
5. resend.com — sign up, verify domain
6. pdfshift.io — sign up, get API key
7. posthog.com — create project
8. sentry.io — create Next.js project
9. cloudflare.com — add your domain
10. namecheap.com — buy pipelineiq.io (~$12/year)

---

## STEP 1 — Create Next.js project (Day 1, ~3 hours)

```bash
npx create-next-app@latest pipelineiq --typescript --tailwind --eslint --app
cd pipelineiq
npm install @anthropic-ai/sdk @clerk/nextjs @supabase/supabase-js @upstash/ratelimit @upstash/redis resend sonner posthog-js
```

Copy all files from this package into your project.
Copy .env.example to .env.local and fill in all keys.

---

## STEP 2 — Configure Clerk (Day 1, ~1 hour)

In Clerk Dashboard:
- Enable Organizations
- Block personal emails (Gmail, Yahoo, Hotmail etc.)
- Set redirect: After sign-up → /dashboard
- Copy keys to .env.local

Add to app/layout.tsx:
```tsx
import { ClerkProvider } from "@clerk/nextjs";
export default function RootLayout({ children }) {
  return <ClerkProvider><html><body>{children}</body></html></ClerkProvider>;
}
```

Create auth pages:
- app/(auth)/sign-in/[[...sign-in]]/page.tsx → <SignIn/>
- app/(auth)/sign-up/[[...sign-up]]/page.tsx → <SignUp/>

Set up Clerk webhook → https://pipelineiq.io/api/webhooks/clerk
Events: organization.created, user.created, organizationMembership.created

---

## STEP 3 — Set up Supabase (Day 2, ~2 hours)

1. Open Supabase → SQL Editor
2. Paste entire schema.sql and run
3. Create storage bucket "reports" (private)
4. Copy URL + keys to .env.local:
   NEXT_PUBLIC_SUPABASE_URL
   NEXT_PUBLIC_SUPABASE_ANON_KEY  
   SUPABASE_SERVICE_ROLE_KEY (NEVER expose client-side)

Note: Clerk handles authentication. Supabase is database only.
Use SUPABASE_SERVICE_ROLE_KEY in all API routes.

---

## STEP 4 — Add rate limiting (Day 2, ~1 hour)

1. upstash.com → Create Database → copy REST URL + token
2. Add to .env.local:
   UPSTASH_REDIS_REST_URL
   UPSTASH_REDIS_REST_TOKEN

Rate limits (adjust in lib/ratelimit.ts):
- 10 audits per user per hour
- 50 audits per organisation per hour

---

## STEP 5 — Convert JSX to Next.js app (Day 3-4, ~5 hours)

CRITICAL CHANGE: In JSX, Claude API was called directly from browser.
In Next.js, the client calls /api/audit/run which calls Claude server-side.

Before (JSX artifact):
  fetch("https://api.anthropic.com/v1/messages", {...})

After (Next.js page):
  fetch("/api/audit/run", {
    method: "POST",
    body: JSON.stringify({ auditType, useCase, inputs })
  })

The API route (app/api/audit/run/route.ts) is already written.
It handles: auth check → rate limit → Claude call → engine fallback → Supabase save → return result.

App structure:
  app/(app)/
    layout.tsx          ← Nav with Clerk UserButton
    dashboard/page.tsx  ← Audit history + stats (calls /api/dashboard)
    audit/page.tsx      ← Type selector
    audit/readiness/    ← Readiness form (calls /api/audit/run)
    audit/cost/         ← Cost form (calls /api/audit/run)
    report/[id]/        ← Report view + PDF export

Keep analysis engine as client-side fallback:
  lib/analysis-engine.ts ← copy runReadinessAnalysis + runCostAnalysis from JSX

---

## STEP 6 — PDF export via PDFShift (Day 4, ~1 hour)

1. pdfshift.io → get API key → add to .env.local as PDFSHIFT_API_KEY
2. In Supabase Storage → reports bucket → add service_role policy for INSERT + SELECT
3. PDF route is already written: app/api/report/pdf/route.ts

Add export button to report page:
  const { pdfUrl } = await fetch("/api/report/pdf", {
    method: "POST", body: JSON.stringify({ auditId })
  }).then(r => r.json());
  window.open(pdfUrl, "_blank");

---

## STEP 7 — Email with Resend (Day 4, ~1 hour)

1. resend.com → verify domain pipelineiq.io → add DNS records to Cloudflare
2. Add RESEND_API_KEY to .env.local
3. Two emails to build:
   a. Report ready: sent when PDF generated (from api/report/pdf/route.ts)
   b. Welcome: sent from Clerk webhook when user signs up

---

## STEP 8 — Deploy and secure (Day 5, ~2 hours)

Deploy to Vercel:
  npm i -g vercel
  vercel --prod

Add all .env.local variables to Vercel Dashboard → Settings → Environment Variables.

Connect domain in Vercel → Domains → pipelineiq.io
Add Vercel's A record to Cloudflare DNS.

Cloudflare security settings:
  SSL/TLS: Full (strict)
  Bot Fight Mode: On
  Always Use HTTPS: On
  WAF: OWASP Core Ruleset enabled

Add PostHog (copy from posthog.com nextjs docs — 5 min):
  Track: audit_started, audit_completed, pdf_exported

Add Sentry:
  npx @sentry/wizard@latest -i nextjs

---

## WHAT YOU HAVE AFTER STEP 8

pipelineiq.io — live domain
Work-email-only auth — Clerk
Both audit types — Claude API + engine fallback
Every audit saved — Supabase (your benchmark data starts day 1)
PDF export — professional report for sharing
Rate limiting — no cost overruns
Analytics — PostHog
Error tracking — Sentry
Security — Cloudflare WAF + Next.js security headers
Total cost: ~$25/month

---

## HOW TO ONBOARD YOUR FIRST PILOT CUSTOMER

1. Send them: https://pipelineiq.io
2. They sign up with work email → Clerk creates their org
3. 10 free pilot credits automatically
4. Run a live session together:
   a. Ask: which API are you deploying AI against?
   b. Run readiness audit on it together
   c. Walk through findings
   d. Export PDF — they email it to their CTO
   e. Ask: did we find anything you didn't already know?
5. If YES → LOI conversation starts here

---

## FUNDRAISING TRIGGER CHECKLIST

You are ready when:
[ ] Platform live at pipelineiq.io
[ ] 3+ enterprise pilot sessions completed  
[ ] 50+ audits in Supabase (real benchmark data)
[ ] PostHog shows: return visits + PDF exports
[ ] 2+ customers in active LOI conversation
[ ] 1+ customer confirmed a finding was a real unknown issue

Walk into investor meetings with this. You will raise.
