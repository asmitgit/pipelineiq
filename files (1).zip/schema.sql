-- ================================================================
-- PIPELINEIQ COMPLETE DATABASE SCHEMA
-- Run this once in your Supabase SQL Editor.
-- All three IP layers are structured from day one.
-- ================================================================

create extension if not exists "uuid-ossp";
create extension if not exists "pg_trgm";

-- ── ORGANISATIONS (synced from Clerk) ────────────────────────
create table public.organisations (
  id                    text primary key,
  name                  text not null,
  vertical              text,
  plan                  text default 'pilot',
  credits_remaining     integer default 10,
  pilot_expires_at      timestamptz default (now() + interval '30 days'),
  loi_status            text default 'none',
  loi_signed_at         timestamptz,
  loi_value_usd         integer,
  notes                 text,
  created_at            timestamptz default now(),
  updated_at            timestamptz default now()
);

-- ── USERS ────────────────────────────────────────────────────
create table public.users (
  id                    text primary key,
  org_id                text references public.organisations(id) on delete cascade,
  email                 text not null unique,
  full_name             text,
  role                  text default 'member',
  audit_count           integer default 0,
  last_active_at        timestamptz,
  created_at            timestamptz default now()
);

-- ── AUDITS (master table — never delete, feeds benchmark) ────
create table public.audits (
  id                        uuid default uuid_generate_v4() primary key,
  org_id                    text references public.organisations(id) on delete set null,
  user_id                   text references public.users(id) on delete set null,
  audit_type                text not null,
  use_case                  text not null,
  api_name                  text not null,
  api_name_clean            text,
  api_url                   text,
  api_url_domain            text,
  auth_type                 text,
  ai_platform               text,
  spec_provided             boolean default false,
  spec_length               integer default 0,
  context_notes             text,
  cost_model                text,
  analysis_source           text default 'engine',
  overall_score             integer,
  verdict                   text,
  fix_weeks                 integer,
  current_monthly_cost_usd  numeric(12,2),
  optimised_monthly_cost_usd numeric(12,2),
  total_savings_usd         numeric(12,2),
  savings_percent           integer,
  tokens_current_per_call   integer,
  tokens_optimised_per_call integer,
  report_pdf_url            text,
  customer_confirmed_findings boolean,
  customer_rating           integer,
  include_in_benchmark      boolean default true,
  benchmark_vertical        text,
  created_at                timestamptz default now(),
  updated_at                timestamptz default now()
);

-- ── AUDIT DIMENSIONS ─────────────────────────────────────────
create table public.audit_dimensions (
  id          uuid default uuid_generate_v4() primary key,
  audit_id    uuid references public.audits(id) on delete cascade,
  name        text not null,
  score       integer not null,
  status      text not null,
  summary     text,
  created_at  timestamptz default now()
);

-- ── AUDIT FINDINGS ───────────────────────────────────────────
create table public.audit_findings (
  id          uuid default uuid_generate_v4() primary key,
  audit_id    uuid references public.audits(id) on delete cascade,
  severity    text not null,
  title       text not null,
  description text,
  fix         text,
  type        text,
  dimension   text,
  confirmed   boolean,
  created_at  timestamptz default now()
);

-- ── AUDIT OPTIMISATIONS (cost audits) ────────────────────────
create table public.audit_optimisations (
  id              uuid default uuid_generate_v4() primary key,
  audit_id        uuid references public.audits(id) on delete cascade,
  type            text not null,
  title           text not null,
  description     text,
  implementation  text,
  savings_usd     numeric(10,2),
  effort          text,
  effort_hours    integer,
  implemented     boolean default false,
  created_at      timestamptz default now()
);

-- ── LAYER 2: API SIGNATURES (benchmark graph nodes) ──────────
create table public.api_signatures (
  id                  uuid default uuid_generate_v4() primary key,
  name_clean          text not null unique,
  display_name        text,
  domain              text,
  is_known            boolean default false,
  audit_count         integer default 0,
  avg_readiness_score numeric(5,2),
  avg_cost_per_call   numeric(10,4),
  last_audited_at     timestamptz,
  created_at          timestamptz default now(),
  updated_at          timestamptz default now()
);

-- ── LAYER 2: BENCHMARK SNAPSHOTS (monthly aggregations) ──────
create table public.benchmark_snapshots (
  id                      uuid default uuid_generate_v4() primary key,
  snapshot_date           date not null,
  vertical                text,
  use_case                text,
  audit_type              text,
  median_readiness_score  numeric(5,2),
  p25_readiness_score     numeric(5,2),
  p75_readiness_score     numeric(5,2),
  pct_deployment_ready    numeric(5,2),
  avg_fix_weeks           numeric(5,2),
  most_common_critical_type text,
  median_monthly_cost_usd numeric(12,2),
  median_savings_pct      numeric(5,2),
  most_common_waste_type  text,
  pct_using_oauth2        numeric(5,2),
  pct_using_basic_auth    numeric(5,2),
  audit_count             integer,
  org_count               integer,
  created_at              timestamptz default now()
);

-- ── LAYER 3: API COMBINATIONS (integration graph edges) ──────
create table public.api_combinations (
  id                  uuid default uuid_generate_v4() primary key,
  api_a_id            uuid references public.api_signatures(id),
  api_b_id            uuid references public.api_signatures(id),
  use_case            text,
  co_occurrence_count integer default 1,
  avg_readiness_score numeric(5,2),
  common_findings     jsonb,
  last_seen_at        timestamptz default now(),
  created_at          timestamptz default now(),
  unique(api_a_id, api_b_id, use_case)
);

-- ── LAYER 3: FAILURE PATTERNS (confirmed finding library) ────
create table public.failure_patterns (
  id                  uuid default uuid_generate_v4() primary key,
  pattern_type        text not null,
  api_names           text[],
  use_cases           text[],
  verticals           text[],
  occurrence_count    integer default 0,
  confirmation_rate   numeric(5,2),
  canonical_title     text,
  canonical_fix       text,
  created_at          timestamptz default now(),
  updated_at          timestamptz default now()
);

-- ── PILOT SESSION TRACKING ───────────────────────────────────
create table public.pilot_sessions (
  id              uuid default uuid_generate_v4() primary key,
  org_id          text references public.organisations(id),
  session_date    timestamptz default now(),
  attendees       text[],
  apis_audited    text[],
  findings_count  integer,
  customer_reaction text,
  next_step       text,
  loi_requested   boolean default false,
  notes           text,
  created_at      timestamptz default now()
);

-- ── ROW LEVEL SECURITY ───────────────────────────────────────
alter table public.organisations  enable row level security;
alter table public.users          enable row level security;
alter table public.audits         enable row level security;
alter table public.audit_dimensions enable row level security;
alter table public.audit_findings   enable row level security;
alter table public.audit_optimisations enable row level security;
alter table public.pilot_sessions   enable row level security;

-- Service role bypasses RLS (used in API routes via SUPABASE_SERVICE_ROLE_KEY)
-- These policies protect the anon key which should never be used server-side anyway
create policy "service_role_all" on public.organisations for all to service_role using (true);
create policy "service_role_all" on public.users          for all to service_role using (true);
create policy "service_role_all" on public.audits         for all to service_role using (true);
create policy "service_role_all" on public.audit_dimensions for all to service_role using (true);
create policy "service_role_all" on public.audit_findings   for all to service_role using (true);
create policy "service_role_all" on public.audit_optimisations for all to service_role using (true);
create policy "service_role_all" on public.pilot_sessions   for all to service_role using (true);

-- ── INDEXES ──────────────────────────────────────────────────
create index idx_audits_org on public.audits(org_id);
create index idx_audits_uc  on public.audits(use_case);
create index idx_audits_type on public.audits(audit_type);
create index idx_audits_api on public.audits(api_name_clean);
create index idx_audits_bench on public.audits(include_in_benchmark) where include_in_benchmark = true;
create index idx_audits_ts  on public.audits(created_at desc);
create index idx_findings_type on public.audit_findings(type);
create index idx_findings_sev  on public.audit_findings(severity);

-- ── TRIGGERS ─────────────────────────────────────────────────
create or replace function handle_updated_at()
returns trigger as $$ begin new.updated_at = now(); return new; end; $$ language plpgsql;

create trigger audit_updated before update on public.audits for each row execute procedure handle_updated_at();
create trigger org_updated   before update on public.organisations for each row execute procedure handle_updated_at();

create or replace function increment_user_audit_count()
returns trigger as $$
begin
  update public.users set audit_count = audit_count + 1, last_active_at = now() where id = new.user_id;
  return new;
end; $$ language plpgsql;

create trigger on_audit_insert after insert on public.audits for each row execute procedure increment_user_audit_count();

-- ── LIVE BENCHMARK VIEW ───────────────────────────────────────
-- Query this for your quarterly industry benchmark report
create or replace view public.v_benchmark_live as
select
  benchmark_vertical as vertical, use_case, audit_type,
  count(*) as audit_count,
  count(distinct org_id) as org_count,
  round(avg(overall_score)::numeric, 1) as avg_score,
  round(percentile_cont(0.5) within group (order by overall_score)::numeric, 1) as median_score,
  round(100.0 * count(*) filter (where overall_score >= 75) / count(*), 1) as pct_ready,
  round(avg(fix_weeks)::numeric, 1) as avg_fix_weeks,
  round(avg(total_savings_usd)::numeric, 0) as avg_savings_identified
from public.audits
where include_in_benchmark = true and overall_score is not null
group by benchmark_vertical, use_case, audit_type;
