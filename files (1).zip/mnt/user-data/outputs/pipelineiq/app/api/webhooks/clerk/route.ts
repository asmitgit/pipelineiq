import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { sendWelcomeEmail } from '@/lib/email'

// Clerk sends webhooks when users and orgs are created
// This syncs Clerk data to your Supabase database

export async function POST(req: NextRequest) {
  const body = await req.json()
  const { type, data } = body

  try {
    if (type === 'organization.created') {
      // New org created in Clerk — add to your database
      await supabaseAdmin.from('organisations').upsert({
        clerk_org_id: data.id,
        name: data.name,
        audits_limit: 10, // default pilot limit
      })
    }

    if (type === 'user.created') {
      // New user — find their org and sync to database
      const orgId = data.organization_memberships?.[0]?.organization?.id

      const { data: org } = await supabaseAdmin
        .from('organisations')
        .select('id')
        .eq('clerk_org_id', orgId)
        .single()

      const primaryEmail = data.email_addresses?.[0]?.email_address
      const fullName = `${data.first_name || ''} ${data.last_name || ''}`.trim()

      await supabaseAdmin.from('users').upsert({
        clerk_user_id: data.id,
        organisation_id: org?.id,
        email: primaryEmail,
        full_name: fullName,
      })

      // Send welcome email
      if (primaryEmail) {
        await sendWelcomeEmail(
          primaryEmail,
          data.first_name || 'there',
          org ? 'your organisation' : 'PipelineIQ'
        )
      }
    }

    if (type === 'organizationMembership.created') {
      // User joined an org — update their org_id
      const clerkUserId = data.public_user_data?.user_id
      const clerkOrgId = data.organization?.id

      const { data: org } = await supabaseAdmin
        .from('organisations')
        .select('id')
        .eq('clerk_org_id', clerkOrgId)
        .single()

      if (org) {
        await supabaseAdmin
          .from('users')
          .update({ organisation_id: org.id })
          .eq('clerk_user_id', clerkUserId)
      }
    }

    return NextResponse.json({ received: true })
  } catch (err) {
    console.error('Webhook error:', err)
    return NextResponse.json({ error: 'Webhook processing failed' }, { status: 500 })
  }
}
