import { auth } from '@clerk/nextjs/server'
import { NextRequest, NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

// Uses PDFShift API (pdfshift.io) — $9/month, zero ops overhead
// Alternative: Puppeteer on Vercel (free but complex to configure)

export async function POST(req: NextRequest) {
  try {
    const { userId, orgId } = auth()
    if (!userId || !orgId) {
      return NextResponse.json({ error: 'Unauthorised' }, { status: 401 })
    }

    const { auditId } = await req.json()
    if (!auditId) {
      return NextResponse.json({ error: 'auditId required' }, { status: 400 })
    }

    // Fetch the audit (verify ownership via org)
    const { data: org } = await supabaseAdmin
      .from('organisations')
      .select('id')
      .eq('clerk_org_id', orgId)
      .single()

    const { data: audit } = await supabaseAdmin
      .from('audits')
      .select('*')
      .eq('id', auditId)
      .eq('organisation_id', org?.id)
      .single()

    if (!audit) {
      return NextResponse.json({ error: 'Audit not found' }, { status: 404 })
    }

    // If PDF already generated, return cached URL
    if (audit.pdf_url) {
      return NextResponse.json({ pdfUrl: audit.pdf_url })
    }

    // Build HTML for the PDF
    const html = buildReportHTML(audit)

    // Call PDFShift API
    const pdfResponse = await fetch('https://api.pdfshift.io/v3/convert/pdf', {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${Buffer.from(`api:${process.env.PDFSHIFT_API_KEY}`).toString('base64')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        source: html,
        format: 'A4',
        margin: '20px',
        landscape: false,
      }),
    })

    if (!pdfResponse.ok) {
      throw new Error(`PDFShift error: ${pdfResponse.status}`)
    }

    const pdfBuffer = await pdfResponse.arrayBuffer()
    const fileName = `reports/${auditId}.pdf`

    // Upload to Supabase Storage
    await supabaseAdmin.storage
      .from('reports')
      .upload(fileName, pdfBuffer, {
        contentType: 'application/pdf',
        upsert: true,
      })

    const { data: { publicUrl } } = supabaseAdmin.storage
      .from('reports')
      .getPublicUrl(fileName)

    // Cache the PDF URL on the audit record
    await supabaseAdmin
      .from('audits')
      .update({ pdf_url: publicUrl })
      .eq('id', auditId)

    return NextResponse.json({ pdfUrl: publicUrl })

  } catch (err) {
    console.error('PDF generation error:', err)
    return NextResponse.json({ error: 'PDF generation failed' }, { status: 500 })
  }
}

function buildReportHTML(audit: any): string {
  const r = audit.report_data
  const isReadiness = audit.audit_type === 'readiness'
  const scoreColor = (n: number) => n >= 75 ? '#059669' : n >= 50 ? '#D97706' : '#DC2626'

  return `
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { font-family: 'Helvetica Neue', Arial, sans-serif; font-size: 13px; color: #111827; line-height: 1.55; }
  .header { background: #0B1120; color: white; padding: 28px 32px; display: flex; justify-content: space-between; align-items: center; }
  .logo { font-size: 18px; font-weight: 600; }
  .logo em { color: #93A8F4; font-style: normal; }
  .header-meta { font-size: 11px; color: rgba(255,255,255,0.5); text-align: right; }
  .body { padding: 32px; }
  .score-section { display: flex; gap: 20px; align-items: flex-start; margin-bottom: 28px; }
  .score-circle { width: 80px; height: 80px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 24px; font-weight: 700; border: 4px solid; flex-shrink: 0; }
  .report-title { font-size: 20px; font-weight: 600; margin-bottom: 8px; }
  .verdict { font-size: 13px; color: #4B5563; line-height: 1.7; margin-bottom: 12px; }
  .tags { display: flex; gap: 6px; flex-wrap: wrap; }
  .tag { font-size: 11px; padding: 3px 9px; border-radius: 99px; border: 1px solid #E5E7EB; color: #6B7280; }
  .tag-warn { background: #FFFBEB; border-color: #FCD34D; color: #D97706; }
  .section-title { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: .08em; color: #9CA3AF; margin-bottom: 12px; margin-top: 24px; }
  .dims-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 10px; }
  .dim { border: 1px solid #E5E7EB; border-radius: 8px; padding: 12px; }
  .dim-header { display: flex; justify-content: space-between; margin-bottom: 6px; }
  .dim-name { font-size: 11px; font-weight: 500; }
  .dim-score { font-size: 12px; font-weight: 700; font-family: monospace; }
  .dim-bar { height: 3px; background: #E5E7EB; border-radius: 99px; margin-bottom: 6px; overflow: hidden; }
  .dim-bar-fill { height: 100%; border-radius: 99px; }
  .dim-summary { font-size: 10px; color: #6B7280; line-height: 1.5; }
  .finding { display: flex; border: 1px solid #E5E7EB; border-radius: 8px; margin-bottom: 8px; overflow: hidden; }
  .finding-bar { width: 4px; flex-shrink: 0; }
  .finding-body { padding: 10px 12px; }
  .finding-title { font-size: 12px; font-weight: 500; margin-bottom: 3px; }
  .finding-sev { display: inline-block; font-size: 10px; font-weight: 600; text-transform: uppercase; padding: 2px 6px; border-radius: 99px; margin-left: 6px; }
  .sev-critical { background: #FEF2F2; color: #DC2626; }
  .sev-high { background: #FFFBEB; color: #D97706; }
  .sev-medium { background: #EFF6FF; color: #1D4ED8; }
  .finding-desc { font-size: 11px; color: #6B7280; margin-bottom: 6px; line-height: 1.55; }
  .finding-fix { font-size: 11px; background: #EFF6FF; color: #1D4ED8; border-radius: 5px; padding: 5px 8px; }
  .metrics-grid { display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 10px; margin-bottom: 20px; }
  .metric { background: #F9FAFB; border: 1px solid #E5E7EB; border-radius: 8px; padding: 12px; }
  .metric-label { font-size: 10px; color: #9CA3AF; margin-bottom: 4px; }
  .metric-val { font-size: 20px; font-weight: 700; font-family: monospace; }
  .opt { border: 1px solid #E5E7EB; border-radius: 8px; padding: 12px; margin-bottom: 8px; border-top: 2px solid #185FA5; }
  .opt-type { font-size: 10px; font-weight: 700; text-transform: uppercase; color: #185FA5; margin-bottom: 4px; }
  .opt-title { font-size: 12px; font-weight: 500; margin-bottom: 4px; }
  .opt-desc { font-size: 11px; color: #6B7280; margin-bottom: 6px; line-height: 1.5; }
  .opt-fix { font-size: 11px; background: #E1F5EE; color: #0F6E56; border-radius: 5px; padding: 5px 8px; margin-bottom: 6px; }
  .opt-footer { display: flex; justify-content: space-between; font-size: 11px; }
  .savings { font-weight: 700; color: #059669; font-family: monospace; }
  .footer { border-top: 1px solid #E5E7EB; padding: 20px 32px; font-size: 11px; color: #9CA3AF; display: flex; justify-content: space-between; }
  .watermark { font-size: 10px; color: #E5E7EB; text-align: center; margin-top: 8px; }
  hr { border: none; border-top: 1px solid #E5E7EB; margin: 20px 0; }
</style>
</head>
<body>
<div class="header">
  <div class="logo">Pipeline<em>IQ</em></div>
  <div class="header-meta">
    ${isReadiness ? 'AI Readiness Report' : 'Cost Optimisation Report'}<br>
    Generated ${new Date().toLocaleDateString('en-GB', { day:'numeric', month:'long', year:'numeric' })}
  </div>
</div>
<div class="body">
  ${isReadiness ? `
  <div class="score-section">
    <div class="score-circle" style="color:${scoreColor(r.overall_score)};border-color:${scoreColor(r.overall_score)}">
      ${r.overall_score}
    </div>
    <div>
      <div class="report-title">${audit.api_name}</div>
      <div class="verdict">${r.verdict}</div>
      <div class="tags">
        <span class="tag">${audit.use_case}</span>
        ${audit.platform ? `<span class="tag">${audit.platform}</span>` : ''}
        ${r.estimated_fix_weeks ? `<span class="tag tag-warn">~${r.estimated_fix_weeks}w to resolve</span>` : ''}
      </div>
    </div>
  </div>
  <div class="section-title">Dimension breakdown</div>
  <div class="dims-grid">
    ${(r.dimensions || []).map((d: any) => `
    <div class="dim">
      <div class="dim-header">
        <span class="dim-name">${d.name}</span>
        <span class="dim-score" style="color:${scoreColor(d.score)}">${d.score}</span>
      </div>
      <div class="dim-bar"><div class="dim-bar-fill" style="width:${d.score}%;background:${scoreColor(d.score)}"></div></div>
      <div class="dim-summary">${d.summary}</div>
    </div>`).join('')}
  </div>
  <hr>
  <div class="section-title">Findings & remediation</div>
  ${(r.findings || []).map((f: any) => {
    const sevCol = f.severity === 'critical' ? '#DC2626' : f.severity === 'high' ? '#F59E0B' : '#3B82F6'
    const sevBg = f.severity === 'critical' ? '#FEF2F2' : f.severity === 'high' ? '#FFFBEB' : '#EFF6FF'
    return `
    <div class="finding">
      <div class="finding-bar" style="background:${sevCol}"></div>
      <div class="finding-body">
        <div class="finding-title">
          ${f.title}
          <span class="finding-sev" style="background:${sevBg};color:${sevCol}">${f.severity}</span>
        </div>
        <div class="finding-desc">${f.description}</div>
        <div class="finding-fix"><strong>Fix:</strong> ${f.fix}</div>
      </div>
    </div>`
  }).join('')}
  ` : `
  <div class="report-title" style="margin-bottom:8px">${audit.api_name}</div>
  <div class="verdict" style="margin-bottom:20px">${r.verdict}</div>
  <div class="metrics-grid">
    ${(r.headline_metrics || []).map((m: any) => `
    <div class="metric">
      <div class="metric-label">${m.label}</div>
      <div class="metric-val" style="color:${m.col}">${m.val}</div>
    </div>`).join('')}
  </div>
  <div class="section-title">Optimisation opportunities</div>
  ${(r.optimizations || []).map((o: any) => `
  <div class="opt">
    <div class="opt-type">${(o.type || '').replace(/_/g, ' ')}</div>
    <div class="opt-title">${o.title}</div>
    <div class="opt-desc">${o.description}</div>
    <div class="opt-fix"><strong>Fix:</strong> ${o.implementation}</div>
    <div class="opt-footer">
      <span class="savings">${o.savings_per_month}</span>
      <span style="color:#9CA3AF">${o.effort} effort · ${o.effort_hours}h engineering</span>
    </div>
  </div>`).join('')}
  `}
</div>
<div class="footer">
  <span>PipelineIQ · team@pipelineiq.io</span>
  <span>Confidential pilot report · ${new Date().getFullYear()}</span>
</div>
</body>
</html>`
}
