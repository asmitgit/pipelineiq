import { NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { createServerClient } from "@/lib/supabase";

export async function GET() {
  const { userId, orgId } = auth();
  if (!userId || !orgId) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  const db = createServerClient(orgId);
  const [{ data: audits }, { data: org }] = await Promise.all([
    db.from("audits").select("id,audit_type,use_case,api_name,overall_score,analysis_source,savings_percent,total_savings_usd,created_at").order("created_at", { ascending: false }).limit(50),
    db.from("organisations").select("name,vertical,plan,credits_remaining,pilot_expires_at,loi_status").eq("id", orgId).single(),
  ]);
  const ra = (audits || []).filter((a: any) => a.audit_type === "readiness");
  const ca = (audits || []).filter((a: any) => a.audit_type === "cost");
  return NextResponse.json({
    audits: audits || [],
    org,
    stats: {
      totalAudits: (audits || []).length,
      readinessAudits: ra.length,
      costAudits: ca.length,
      avgReadinessScore: ra.length ? Math.round(ra.reduce((s: number, a: any) => s + (a.overall_score || 0), 0) / ra.length) : null,
      deploymentReady: ra.filter((a: any) => (a.overall_score || 0) >= 75).length,
      totalSavingsIdentified: Math.round(ca.reduce((s: number, a: any) => s + (a.total_savings_usd || 0), 0)),
    },
  });
}