import { NextRequest, NextResponse } from "next/server";
import { auth } from "@clerk/nextjs/server";
import { checkRateLimits } from "@/lib/ratelimit";
import { callClaude, buildReadinessPrompt, buildCostPrompt } from "@/lib/claude";
import { saveAudit } from "@/lib/save-audit";

const UC_NAMES: Record<string, string> = { voice:"Voice bot", chat:"Chat bot", copilot:"AI co-pilot", rag:"RAG pipeline", agentic:"Agentic AI", data:"Data AI" };
const MCOSTS: Record<string, number> = { claude:3, gpt4:5, gemini:3.5, llama:0.5, mistral:4, custom:3 };
const VOL_MAP: Record<string, (i: any) => { metric: string; value: number }> = {
  voice:   i => ({ metric: "calls/day",   value: parseInt(i.callsDay   || "1000") }),
  chat:    i => ({ metric: "convs/day",   value: parseInt(i.convsDay   || "500") }),
  copilot: i => ({ metric: "queries/day", value: parseInt(i.queriesHr || "12") * parseInt(i.agents || "25") * parseInt(i.hoursDay || "8") }),
  rag:     i => ({ metric: "queries/day", value: parseInt(i.queriesDay || "1000") }),
  agentic: i => ({ metric: "runs/day",    value: parseInt(i.runsDay   || "200") }),
  data:    i => ({ metric: "records/run", value: parseInt(i.recordsRun || "50000") }),
};

export async function POST(req: NextRequest) {
  try {
    const { userId, orgId } = auth();
    if (!userId || !orgId) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });

    const rl = await checkRateLimits(userId, orgId);
    if (!rl.allowed) return NextResponse.json({ error: rl.message }, { status: 429 });

    const { auditType, useCase, inputs } = await req.json();
    if (!inputs?.apiName?.trim()) return NextResponse.json({ error: "API name required" }, { status: 400 });

    const ucName = UC_NAMES[useCase] || useCase;
    let result: Record<string, any> | null = null;
    let source = "engine";

    if (auditType === "readiness") {
      result = await callClaude(buildReadinessPrompt(inputs, ucName));
      if (result) source = "live";
    } else if (auditType === "cost") {
      const mCost = parseFloat(inputs.customRate || "") || MCOSTS[inputs.model] || 3;
      const vol = (VOL_MAP[useCase] || VOL_MAP.voice)(inputs);
      result = await callClaude(buildCostPrompt(inputs, ucName, mCost, vol.metric, vol.value));
      if (result) source = "live";
    }

    // Signal engine fallback if Claude failed
    if (!result) return NextResponse.json({ success: true, source: "engine", auditId: null });

    const auditId = await saveAudit({ orgId, userId, auditType, useCase, inputs, result, source });
    return NextResponse.json({ success: true, auditId, result, source, creditsRemaining: rl.remaining });
  } catch (e) {
    console.error("Audit route error:", e);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}